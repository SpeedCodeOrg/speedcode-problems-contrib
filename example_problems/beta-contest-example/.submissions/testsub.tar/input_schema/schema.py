#
# Definition of the input schema for users.

from typing import Annotated, Union, Literal, List, Optional, Tuple
from enum import Enum, IntEnum
from pydantic import BaseModel

class Input(BaseModel):
    byte_array : List[int]
    search_ranges : List[Tuple[int, int]]
