from .schema import Input
import numpy as np
import json
from pydantic.json import pydantic_encoder
import argparse

parser = argparse.ArgumentParser(prog='Generate a random input')
parser.add_argument('--seed', type=int, default=42)
parser.add_argument('--array_size', type=int, required=True)
parser.add_argument('--num_ranges', type=int, required=True)
parser.add_argument('--range_size', type=int, required=True)
parser.add_argument('--output_path', type=str, required=True)
args = parser.parse_args()

if not args.output_path.endswith('.json'):
    print("Error, the output path must end with the .json extension")
    quit()

array = list(np.random.randint(0, 256, args.array_size))
ranges = []

for x in range(args.num_ranges):
    start = np.random.randint(0,args.array_size)
    end = start + args.range_size
    if end > args.array_size:
        end = args.array_size
    ranges.append([start,end])

pInput = Input(byte_array = array, search_ranges = ranges)
open(args.output_path,'w+').write(json.dumps(pInput, default=pydantic_encoder))

