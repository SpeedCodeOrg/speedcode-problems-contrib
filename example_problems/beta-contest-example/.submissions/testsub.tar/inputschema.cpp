//  To parse this JSON data, first install
//
//      json.hpp  https://github.com/nlohmann/json
//
//  Then include this file, and then do
//
//     Inputschema data = nlohmann::json::parse(jsonString);

#pragma once

#include <nlohmann/json.hpp>

namespace quicktype {
    using nlohmann::json;

    #ifndef NLOHMANN_UNTYPED_quicktype_HELPER
    #define NLOHMANN_UNTYPED_quicktype_HELPER
    inline json get_untyped(const json & j, const char * property) {
        if (j.find(property) != j.end()) {
            return j.at(property).get<json>();
        }
        return json();
    }

    inline json get_untyped(const json & j, std::string property) {
        return get_untyped(j, property.data());
    }
    #endif

    struct Inputschema {
        std::vector<int64_t> byte_array;
        std::vector<std::vector<int64_t>> search_ranges;
    };
}

namespace quicktype {
    void from_json(const json & j, Inputschema & x);
    void to_json(json & j, const Inputschema & x);

    inline void from_json(const json & j, Inputschema& x) {
        x.byte_array = j.at("byte_array").get<std::vector<int64_t>>();
        x.search_ranges = j.at("search_ranges").get<std::vector<std::vector<int64_t>>>();
    }

    inline void to_json(json & j, const Inputschema & x) {
        j = json::object();
        j["byte_array"] = x.byte_array;
        j["search_ranges"] = x.search_ranges;
    }
}
