# Find zero byte

Given an array of bytes, return a pointer to the first zero byte in the array. If there
is no zero byte in the array, return ``nullptr``.

This exercise asks you to solve an easier variant of the "needle and haystack" problem
in which you are given an array of bytes and are asked to find the first byte equal to some
particular value. The "needle and haystack" problem has useful applications in the design
of fast hash tables with open addressing.

**Note** The interface for ``solution_entry`` that we provide you includes a ``needle`` argument,
but for this exercise ``needle == 0`` in all tests and benchmarks.

## Constraints

The starting address of the array is guaranteed to be 16-byte aligned, and the array length is guaranteed to be a multiple of 16.

## Word-level parallelism

The reference code checks the array byte-by-byte to find a zero element. A better approach is to iterate over the
array in chunks and check whether a chunk contains a zero-byte. By choosing a chunk-size that fits into a single register
on the CPU, you can (with some cleverness) check whether any byte in the chunk is zero with a few instructions.

One approach to checking whether a word contains a zero byte is to use a bit-trick from [Bit twiddling hacks](https://graphics.stanford.edu/~seander/bithacks.html) that checks whether a 32-bit word contains
any zero byte. 

```c
#define haszero(v) (((v) - 0x01010101UL) & ~(v) & 0x80808080UL)
```

You can iterate over the byte array in 32-bit (4 byte) chunks by using `reinterpret_cast` as follows:

```c
for (; start < end; start += sizeof(uint32_t)) {
  if(haszero(*reinterpret_cast<const uint32_t*>(start))) {
    for (int i = 0; i < sizeof(uint32_t); i++) {
      if (start[i] == needle) return start+i;
    }
  }
}
```

Of course, it would be even better to operate on larger chunks of the byte-array --- e.g., 64-bit chunks or even larger.

**Hint** You might consider trying to generalize the above bit-trick to operate on uint64_t data types.

## Vector instructions

You can improve performance further by operating on larger 128-bit chunks of the byte-array and checking whether the 128-bit
word contains a zero byte using SSE vector instructions. The following is some guidance to help you try this approach.

The vector instructions that we use in this exercise are enabled by including
the following header in your C++ file:

```cpp
#include <emmintrin.h>
```

The SSE instructions use a type called `__m128i`, which is a 128-bit value that
can be viewed as 16 8-bit integers.  (It can also be viewed other ways, such as
8 16-bt integers.  We'll stick to the 16 8-bit integers view for this exercise.)
There are special registers in the processor (the XMM registers) that can hold
128-bit values.


The `__m128i` type could have been defined in C++ as follows:

```cpp
class __m128i {
  private:
    uint8_t v[16];
    // Declare friend functions so we can access the private member variable.  
    friend __m128i _mloadu_si128(const __m128i *p);
    friend __m128i _mm_set1_epi9(uint8 v);
    friend __m128i _mm_cmpeq_epi8(__m128i a, __m128i b);
};
```

Note that `v` is `private`, so you cannot write the following

```cpp
uint8_t FirstByte(__m128i x) {
  return x.v[0]; // Won't compile
}
```

That's why we declared the three `friend` functions.

That's not how `__m128i` is actually defined, but it's convenient to imagine it
that way for the following discussion.

You can learn more about the Intel instructions at
https://www.intel.com/content/www/us/en/docs/intrinsics-guide/index.html.  For
these exercises you won't need to refer to that the Intel manausl, however.

## Relevant SSE vector instructions

The following are some key instructions that will help you implement find-zero-byte using SSE vector instructions.

### mloadu_si128

```cpp
__m128i _mloadu_si128(const __m128i *p);
```

Effect: Loads an `__m128i` from a pointer.  There are no alignment constraints
on p, so you can take any pointer and convert it to a pointer to a `__m128i` and
load it.

Equivalent implemententation:
```cpp
__m128i _mloadu_si128(const __m128i *p) {
  __m128i value;
  for (size_t i = 0; i < 16; ++i) {
    value.v[i] = p->v[i];
  }
  return value;
}
```

Requires: The next 16 bytes, starting at `*p` must be valid memory locations.

### mm_set1_epi8

```cpp
__m128i _mm_set1_epi9(uint8 v);
```

Effect: Returns a `__m128i` in which all the bytes are set to `v`.

Equivalent implementation:
```cpp
__m128i _mm_set1_epi9(uint8 v) {
  __m128i result;
  for (size_t i = 0; i < 16; ++i) {
    result.v[i] = v;
  }
  return result;
}

```

### mm_cmpeq_epi8

```cpp
__m128i _mm_cmpeq_epi8(__m128i a, __m128i b);
```

Effect: Returns a `__m128i` which contains a pairwise equality comparison
between `a` and `b`, containing `0xFF` if the corresponding elements are equal
and `0` if they are not equal.  That is `__mm_cmpeq_epi8(a, b).v[i] == (a.v[i]
== b.v[i]) ? 0xFF : 0`.

Equivalent implementation:

```cpp
__m128i _mm_cmpeq_epi8(__m128i a, __m128i b) {
  __m128i result;
  for (size_t i = 0; i < 16; ++i) {
    if (a.v[i] == b.v[i]) {
      result.v[i] = 0xFF;
    } else {
      result.v[i] = 0;
    }
  }
  }
```

### mm_movemask_epi8

```cpp
int _mm_movemask_epi8(__m128i a);
```

Effect: Returns an integer, in which bit `i` of the returned reesult equals the
most signficant bit of `a.v[i]`.

Equivalent implementation:

```cpp
int _mm_movemask_epi8(__m128i a) {
  int result = 0;
  for (size_t i = 0; i < 16; ++i ) {
    result |= (a.v[i] >> 7) << i;
  }
  return result;
```

### __builtin_ctzll

You will also need a built-in function that tells you the index of the lowest nonzero bit in an integer.

```cpp
int __builtin_ctzl(uint32_t v)
```

Effect: Returns the number of trailing 0-bits in `v`, starting at the least
significant bit position.  (That is, returns the smallest number `i` such that
the `i`th bit of `v` is nonzero.)  If x is `v`, the result is undefined.

Equivalent implementation:

```cpp
int __builtin_ctzl(uint32_t v) {
  for (size_t i = 0; i < 32; ++i) {
    if ((v >> i) % 2 == 1) {
      return i;
    }
  }
  fail(); // Undefined behavior if we get here.
}
```
