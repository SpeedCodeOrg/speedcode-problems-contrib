#include <solution.hpp>
#include <inttypes.h>
#include <emmintrin.h>

#define haszero(v) (((v) - 0x01010101UL) & ~(v) & 0x80808080UL)

const uint8_t* solution_entry(uint8_t needle, const uint8_t* start, const uint8_t* end) {
	  for (; start < end; start += 4) {
		      if(haszero(*reinterpret_cast<const uint32_t*>(start))) {
                         for (int i = 0; i < 4; i++) {
                            if (start[i] == needle) return start+i;
			 }
		      }
          }
	  return nullptr;
}
