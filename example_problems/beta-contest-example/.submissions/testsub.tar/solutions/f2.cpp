#include <solution.hpp>
#include <inttypes.h>
#include <emmintrin.h>


#define haszero_64b(v) (((v) - 0x0101010101010101UL) & ~(v) & 0x8080808080808080UL)

const uint8_t* solution_entry(uint8_t needle, const uint8_t* start, const uint8_t* end) {
	  for (; start < end; start += 8) {
		      if(haszero_64b(*reinterpret_cast<const uint64_t*>(start))) {
                         for (int i = 0; i < 8; i++) {
                            if (start[i] == needle) return start+i;
			 }
		      }

          }
	  return nullptr;
}

