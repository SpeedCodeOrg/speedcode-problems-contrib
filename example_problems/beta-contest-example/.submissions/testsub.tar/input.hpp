#include "solution.hpp"
#include <optional>
#include <string>
#include <nanobench.h>

const uint8_t* reference_solution(uint8_t needle, const uint8_t* start, const uint8_t* end) {
  for (; start < end; ++start) {
    if (*start == needle) {
      return start;
    }
  }
  return nullptr;
}

class ProblemInput {
    std::vector<uint8_t> data;
    uint8_t* data_ptr;
    uint8_t* data_end;
    size_t range;
    std::vector<std::pair<int, int>> search_ranges;
    size_t N;
    ankerl::nanobench::Rng rng;

  public:
    // Default problem input
    ProblemInput() : ProblemInput(16*10000) { }

    ProblemInput(size_t N) {
	this->N = N;
	this->rng = ankerl::nanobench::Rng(42);
        data.resize(N);
        for (size_t i = 0; i < N; i++) {
            data[i] = rng.bounded(256);
	}
	range = 4096;
	data_ptr = (&data[0]);
	data_end = (&data[0]) + N;
    }

    ProblemInput(std::string inp_name, quicktype::Inputschema input) {
	this->N = input.byte_array.size();
	this->rng = ankerl::nanobench::Rng(42);
        data.resize(N);
        for (size_t i = 0; i < N; i++) {
            data[i] = (uint8_t) input.byte_array[i];
	}
        for (int i = 0; i < input.search_ranges.size(); i++) {
            search_ranges.push_back(std::make_pair(input.search_ranges[i][0], input.search_ranges[i][1])); 
	}
    }

    auto run(decltype(solution_entry) F = solution_entry) {
       std::vector<const uint8_t*> results(search_ranges.size());
       for (int i = 0; i < search_ranges.size(); i++) {
         const uint8_t* start = data.data() + search_ranges[i].first;
	 const uint8_t* end = data.data() + search_ranges[i].second;
         results[i] = F(0, start, end); 
       }
       ankerl::nanobench::doNotOptimizeAway(results);
       return results;
       //size_t offset = 16*rng.bounded(N/16);
       //const uint8_t* start = (&data[0]) + offset;
       //const uint8_t* end = start + range;
       //if (end > data_end) end = data_end;
       //auto res = solution_entry(0, start, end);
       //ankerl::nanobench::doNotOptimizeAway(res);
    }

    std::string result_to_string(const uint8_t* ret) {
       if (ret == nullptr) return "nullptr";
       return std::to_string((size_t) ((char*) ret - (char*) data.data()));
    }
    std::optional<std::string> check() {
       std::vector<const uint8_t*> results_ref = run(reference_solution);
       std::vector<const uint8_t*> results_sub = run();
       for (int i = 0; i < results_ref.size(); i++) {
         if (results_ref[i] != results_sub[i]) {
            return "Search range: " + std::to_string(search_ranges[i].first) + "," + std::to_string(search_ranges[i].second) + " expected: " + result_to_string(results_ref[i]) + " actual: " + result_to_string(results_sub[i]);
	 }
       }
       return std::nullopt;
       //for (int i = 0; i < 1024; i++) {
       //    size_t offset = 16*rng.bounded(N/16);
       //    const uint8_t* start = (&data[0]) + offset;
       //    const uint8_t* end = start + range;
       //    if (end > data_end) end = data_end;
       //    auto res = solution_entry(0, start, end);
       //    auto res2 = reference_solution(0, start, end);
       //    if (res != res2) {
       //        return "start=" + std::to_string(offset) + " end=" + std::to_string(end-start + offset) + " expected: " + std::to_string(res2-start) + " got: " + std::to_string(res-start);
       //    }
       //}
       //return std::nullopt;
       // std::make_tuple(true, ""); 
    }
};
