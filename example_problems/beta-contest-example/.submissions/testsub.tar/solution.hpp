#ifndef SOLUTION_HPP
#define SOLUTION_HPP
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <vector>
#include <math.h>
#include <inttypes.h>
__attribute__((weak)) const uint8_t* solution_entry(
		    uint8_t needle,
		        const uint8_t* start, 
			    const uint8_t* end);
#endif
