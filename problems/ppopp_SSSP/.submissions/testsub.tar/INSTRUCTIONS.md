
# Instructions for using DYNAMIC_INPUT_TARGETS

By default, the commands for `make correctness` and `make benchmark` will run on all inputs in the inputs/ directory. You can target specific benchmarks by using the DYNAMIC_INPUT_TARGETS environment variable.

For example, you can run the following command: 

```bash
DYNAMIC_INPUT_TARGETS=random_10k_50k.json,random_1k_5k.json make correctness
```

The above precise format is used by the server, but there is a little bit of flexibility. For example, the following should all work and be equivalent:

```bash
DYNAMIC_INPUT_TARGETS="random_10k_50k,random_1k_5k" make correctness
DYNAMIC_INPUT_TARGETS="random_10k_50k.json,random_1k_5k.json" make correctness
DYNAMIC_INPUT_TARGETS="random_10k_50k.json,random_1k_5k.json" make correctness
DYNAMIC_INPUT_TARGETS="./inputs/random_10k_50k.json,./inputs/random_1k_5k.json" make correctness
DYNAMIC_INPUT_TARGETS="./inputs/random_10k_50k,./inputs/random_1k_5k" make correctness
```

# Submitting the problem to Speedcode

* Go to speedcode.org/contribute and copy your API key. Note that you may be redirected to the homepage if your access token is not fresh. If this happens, just try to load speedcode.org/contribute again and it should work.

* Copy and paste your API key.

* Run `make submit` and when prompted paste in your API key.


